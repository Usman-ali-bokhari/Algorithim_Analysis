//============================================================================
// Name        : Q1.cpp
// Author      : Usman Ali bokahri
//============================================================================

#include <iostream>
#include <fstream>
#include <thread>
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <Windows.h>
#include <stack>
#include <string>
using namespace std;



int count1s;
int ZeroVal;
int originalVal;



void GetFile(int* arr,int size,int* arr2) {
	ofstream MyFile("TDash.txt");
	for (int i = 0; i < size; i++)
		MyFile << arr[i] << endl;
	MyFile.close();
}

void generateT(int count,int* arr) {
	string filename = "TRandom.txt";
	ofstream MyFile("TRandom.txt");
	for (int i = 0; i < count; i++) {
		int x = rand() % 2;
		MyFile << x << endl;
		arr[i] = x;
	}
	MyFile.close();

}

int returnClauseAns(string clause, int* Tvals) {
	int AdjArr[11][11];
	int arr[10];
	int varCount = 0;
	string num;
	for (int i = 0; i < clause.length()-1; i++) {
		if (clause[i] == '\t') {
			//cout << num << endl;
			if (stoi(num) < 0) {
				if (varCount == 0) {
					//cout << "Creating edge between N1 and OR1" << endl;
					AdjArr[varCount][varCount + 6] = -1 * stoi(num);
				}
				//cout << "Creating edge between N" << varCount << "and OR" << varCount-1;
				AdjArr[varCount][varCount + 5] = -1 * stoi(num);
			}
			else {
				if (varCount == 0) {
					//cout << "Creating edge between N1 and OR1" << endl;
					AdjArr[varCount][varCount + 6] = stoi(num);
				}
				//cout << "Creating edge between N" << varCount << "and OR" << varCount - 1 << endl;
				AdjArr[varCount][varCount + 5] = stoi(num);
			}
			varCount++;
			num = "";
			continue;
		}
		num += clause[i];	
	}
	//cout << "Graph creation complete!" << endl;
	for (int i = 0; i < varCount; i++) {
		if (varCount == 1) {
			if (Tvals[AdjArr[i][i + 6]]) {
				count1s++;
				//cout << "Answer of OR1 is true hence our output is 1" << endl;
				return 1;
			}
			return 0;
		}
		if (i == 0 && (Tvals[AdjArr[i][i + 6]] || Tvals[AdjArr[i + 1][i + 6]])) {
			count1s++;
			//cout << "Answer of OR1 is true hence our output is 1" << endl;
			return 1;
		}
		if (i > 1 && (Tvals[AdjArr[i][i + 5]]) ) {
			count1s++;
			//cout << "Answer of OR"<<i-1<<" is true hence our output is 1" << endl;
			return 1;
		}
	}
	return 0;
}

void calculateClauses(string* clauses, int* Tvals,int count,int* final) {
	for (int i = 0; i < count; i++) {
		//cout << "Creating graph and entering value..." << endl;
		final[i] = returnClauseAns(clauses[i],Tvals);
		//cout << "Answer has been calculated" << endl;
	}
}

void kflip(int* Tvals, int size, string* clauses, int* final, int k) {

	for (int i = 0; i < size; i++) {
		if (count1s - originalVal == k) {
			cout << "K flips successfull" << endl;
			cout << "***********************************************" << endl;
			return;
		}
		if (Tvals[i] == 0) {
			cout << "Preforming K-flips..." << endl;
			Tvals[i] = 1;
			count1s = 0;
			calculateClauses(clauses, Tvals, size, final);
			cout << originalVal << " .. " << count1s << endl;
			if (originalVal > count1s) {
				cout << "Reverting change..." << endl;
				Tvals[i] = 0;
				count1s = 0;
				calculateClauses(clauses, Tvals, size, final);
			}
			else if (count1s - originalVal > k) {
				cout << "Reverting change..." << endl;
				Tvals[i] = 0;
				count1s = 0;
				calculateClauses(clauses, Tvals, size, final);
			}
			cout << "Value of 1s after atemped flip: " << count1s << endl;
			cout << "***********************************************" << endl;
		}
	}
}

int main() {
	srand(time(NULL));
	int K = 5;
	string line;
	int count = 0;
	ifstream mFile;
	mFile.open("dataset.txt",ios::out);

	if (mFile.is_open())
	{
		while (mFile.peek() != EOF)
		{
			getline(mFile, line);
			count++;
		}
		mFile.close();
	}
	else
		cout << "Couldn't open the file\n";


	string* clauses = new string[count];
	ifstream mFile1;
	mFile1.open("dataset.txt", ios::out);
	if (mFile1.is_open())
	{
		int i = 0;
		while (mFile1.peek() != EOF)
		{
			getline(mFile1, line);
			clauses[i] = line;
			i++;
		}
		mFile1.close();
	}
	else
		cout << "Couldn't open the file\n";
	
	int* Tvals = new int[count];
	generateT(count, Tvals);
	/*for (int i = 0; i < count; i++)
		cout << Tvals[i];*/
	int* final = new int[count];
	calculateClauses(clauses, Tvals, count, final);
	cout << "Creating graphs and solving clauses!" << endl;
	cout << "Done!" << endl;
	cout << "***********************************************" << endl;
	/*for (int i = 0; i < count; i++) {
		cout << final[i] << endl;
	}*/
	originalVal = count1s;
	kflip(Tvals, count, clauses, final,K);
	GetFile(final, count,Tvals);
	cout << "The value of T` has been stored!" << endl;
	cout << "Exiting algo..." << endl;
	cout << "***********************************************" << endl;
}
